#!/usr/bin/python2.7
# coding: utf-8
import threading
import time, os, sys

from threadB import ThreadB
from threadC import ThreadC

class ThreadA (threading.Thread):
    def __init__ (self, name):
        super(ThreadA, self).__init__()
        self._stop = threading.Event()
        self.name = name

    def run (self):
        time.sleep(1)
        while not self.stopped():
            try:
                b = ThreadB("nameB")
                c = ThreadC("nameC")
                d = threading.Thread(target=self.nothing, args=[])

                b.start()
                c.start()
                d.start()
                
                threads_names = [x.name for x in threading.enumerate()]
                print "\n(%s)\n%s\n" % (len(threads_names), threads_names)

                b.join(1)
                c.join(1)

            except Exception as e:
                print "error: %s" % e

    def stopped (self):
        return self._stop.isSet()


    def nothing (self):
        while True:
            time.sleep(1)
